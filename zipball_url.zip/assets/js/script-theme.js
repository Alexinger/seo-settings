jQuery(document).ready(function ($) {
    $('#main-wrapper').addClass('row-fluid');
});