<?php
/**
Template Name: Мой шаблон №1
 */
echo "Hello pages";