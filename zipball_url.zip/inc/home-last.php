<?php

echo "New page plugins";