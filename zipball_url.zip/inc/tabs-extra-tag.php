<?php

echo '<form class="row">
	<div class="form-group col-6">
		<label for="formGroupExampleInput">Title для товара</label>
		<input type="text" class="form-control" id="formGroupExampleInput" placeholder="Название шорткода">
	</div>
	<div class="form-group col-6">
		<label for="formGroupExampleInput2">Another label</label>
		<input type="text" class="form-control" id="formGroupExampleInput2" placeholder="Another input">
	</div>
</form>';