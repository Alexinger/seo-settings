<?php
//if (! is_admin()) {remove_menu_page( 'edit.php' ); }
// echo '<pre>' . print_r( $GLOBALS['menu'], TRUE) . '</pre>';

// $screen = get_current_screen();
// echo '<pre>' . print_r($screen, TRUE) . '</pre>';
